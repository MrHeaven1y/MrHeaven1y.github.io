'use client';

import { motion } from 'framer-motion';
import {
  Brain,
  Eye,
  Cpu,
  GitBranch,
  Server,
  Globe,
  Sparkles,
  Layers,
} from 'lucide-react';
import { cn } from '@/lib/utils';
import {
  fadeUp,
  staggerContainer,
  staggerItem,
  viewportConfig,
} from '@/lib/animations';
import { techMarquee } from '@/lib/data';
import SectionTitle from '@/components/ui/SectionTitle';
import GlassCard from '@/components/ui/GlassCard';
import AnimatedCounter from '@/components/ui/AnimatedCounter';
import TextReveal from '@/components/ui/TextReveal';
import InfiniteMarquee from '@/components/ui/InfiniteMarquee';

const stats = [
  { value: 10, suffix: '+', label: 'Projects Shipped' },
  { value: 4, suffix: '', label: 'ML Frameworks Built' },
  { value: 97, suffix: '%', label: 'Peak Accuracy' },
  { value: 3, suffix: '', label: 'Systems Languages' },
];

const domains = [
  { name: 'Deep Learning', icon: Brain },
  { name: 'Computer Vision', icon: Eye },
  { name: 'Systems Programming', icon: Cpu },
  { name: 'Autograd / Autodiff', icon: GitBranch },
  { name: 'Distributed Training', icon: Server },
  { name: 'Edge Inference', icon: Globe },
  { name: 'Generative AI', icon: Sparkles },
  { name: 'MLOps', icon: Layers },
];

export default function About() {
  return (
    <section id="about" className="py-24 md:py-32 px-5 sm:px-6 md:px-12 lg:px-24">
      <div className="max-w-7xl mx-auto">
        <SectionTitle title="About" number="01" />

        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 mt-12 md:mt-16">
          {/* Left Column: Bio + Stats */}
          <div>
            <TextReveal text="I build AI systems at the intersection of deep learning research and systems engineering. From implementing reverse-mode autodiff engines in C to training vision transformers across multiple GPUs, I focus on understanding and building foundational AI infrastructure — not just using it. Every project in my portfolio involves building core components from scratch, because real understanding comes from first principles." />

            <motion.div
              variants={staggerContainer}
              initial="hidden"
              whileInView="visible"
              viewport={viewportConfig}
              className="grid grid-cols-2 gap-3 sm:gap-4 mt-10 md:mt-12"
            >
              {stats.map((stat) => (
                <motion.div key={stat.label} variants={staggerItem}>
                  <GlassCard className="p-4 sm:p-6 text-center">
                    <div className="text-2xl sm:text-3xl md:text-4xl font-heading font-bold text-white">
                      <AnimatedCounter
                        value={stat.value}
                        suffix={stat.suffix}
                        className="text-2xl sm:text-3xl md:text-4xl"
                      />
                    </div>
                    <p className="text-secondary text-xs sm:text-sm mt-2 font-mono">
                      {stat.label}
                    </p>
                  </GlassCard>
                </motion.div>
              ))}
            </motion.div>
          </div>

          {/* Right Column: Domain Expertise */}
          <motion.div
            variants={staggerContainer}
            initial="hidden"
            whileInView="visible"
            viewport={viewportConfig}
            className="grid grid-cols-2 gap-3"
          >
            {domains.map((domain) => {
              const Icon = domain.icon;
              return (
                <motion.div
                  key={domain.name}
                  variants={staggerItem}
                  whileHover={{ y: -2 }}
                  className={cn(
                    'glass-subtle rounded-xl p-3 sm:p-4 cursor-default',
                    'border border-transparent transition-all duration-300',
                    'hover:border-accent/20 hover:shadow-[0_0_15px_rgba(0,245,255,0.05)]'
                  )}
                >
                  <Icon className="w-5 h-5 text-accent mb-2" />
                  <h3 className="font-heading text-xs sm:text-sm font-semibold text-white">
                    {domain.name}
                  </h3>
                </motion.div>
              );
            })}
          </motion.div>
        </div>

        {/* Tech Marquee */}
        <div className="mt-20 md:mt-24">
          <InfiniteMarquee items={techMarquee} />
        </div>
      </div>
    </section>
  );
}
