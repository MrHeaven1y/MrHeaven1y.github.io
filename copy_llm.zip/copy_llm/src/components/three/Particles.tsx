'use client';

import { useRef, useMemo } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';

const PARTICLE_COUNT = 1500;

export default function Particles() {
  const pointsRef = useRef<THREE.Points>(null);

  const geometry = useMemo(() => {
    const geo = new THREE.BufferGeometry();
    const positions = new Float32Array(PARTICLE_COUNT * 3);

    for (let i = 0; i < PARTICLE_COUNT; i++) {
      const i3 = i * 3;
      positions[i3] = (Math.random() - 0.5) * 30;     // x ∈ [-15, 15]
      positions[i3 + 1] = (Math.random() - 0.5) * 30; // y ∈ [-15, 15]
      positions[i3 + 2] = Math.random() * 15 - 10;     // z ∈ [-10, 5]
    }

    geo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    return geo;
  }, []);

  const material = useMemo(() => {
    return new THREE.PointsMaterial({
      size: 0.015,
      color: 0xffffff,
      transparent: true,
      opacity: 0.6,
      sizeAttenuation: true,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
    });
  }, []);

  useFrame((state, delta) => {
    const points = pointsRef.current;
    if (!points) return;

    // Slow rotation of entire particle field
    points.rotation.y += delta * 0.02;
    points.rotation.x += delta * 0.01;

    // Gentle wave motion on individual particles
    const positions = points.geometry.attributes.position;
    const posArray = positions.array as Float32Array;
    const time = state.clock.elapsedTime;

    for (let i = 0; i < PARTICLE_COUNT; i++) {
      const i3 = i * 3;
      const x = posArray[i3];
      posArray[i3 + 1] += Math.sin(time + x * 0.5) * 0.002;
    }

    positions.needsUpdate = true;
  });

  return (
    <points ref={pointsRef} geometry={geometry} material={material} frustumCulled={false} />
  );
}
