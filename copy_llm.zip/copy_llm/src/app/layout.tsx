import type { Metadata, Viewport } from "next";
import { inter, spaceGrotesk, jetbrainsMono } from "@/lib/fonts";
import "./globals.css";

export const metadata: Metadata = {
  title: "Dibyendu Mukherjee — AI Engineer",
  description:
    "AI Engineer building intelligent systems from first principles. From custom autograd engines in C to production vision transformers with distributed training.",
  keywords: [
    "AI Engineer",
    "Machine Learning",
    "Deep Learning",
    "Computer Vision",
    "Systems Programming",
    "PyTorch",
    "WebAssembly",
    "Vision Transformer",
    "Autograd",
    "Portfolio",
  ],
  authors: [{ name: "Dibyendu Mukherjee" }],
  creator: "Dibyendu Mukherjee",
  openGraph: {
    type: "website",
    locale: "en_US",
    title: "Dibyendu Mukherjee — AI Engineer",
    description:
      "Building intelligent systems from first principles. Custom autograd engines, vision transformers, and production ML infrastructure.",
    siteName: "Dibyendu Mukherjee",
  },
  twitter: {
    card: "summary_large_image",
    title: "Dibyendu Mukherjee — AI Engineer",
    description:
      "Building intelligent systems from first principles. Custom autograd engines, vision transformers, and production ML infrastructure.",
  },
  robots: {
    index: true,
    follow: true,
  },
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  themeColor: "#050505",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html
      lang="en"
      className={`${inter.variable} ${spaceGrotesk.variable} ${jetbrainsMono.variable}`}
    >
      <head>
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{
            __html: JSON.stringify({
              "@context": "https://schema.org",
              "@type": "Person",
              name: "Dibyendu Mukherjee",
              jobTitle: "AI Engineer",
              url: "https://dibyendu.dev",
              sameAs: ["https://github.com/MrHeaven1y"],
              knowsAbout: [
                "Artificial Intelligence",
                "Machine Learning",
                "Deep Learning",
                "Computer Vision",
                "Systems Programming",
                "WebAssembly",
              ],
            }),
          }}
        />
      </head>
      <body className="bg-bg text-primary antialiased">{children}</body>
    </html>
  );
}
