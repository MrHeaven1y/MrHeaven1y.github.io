"use client";

import { useState, useCallback, useEffect } from "react";
import dynamic from "next/dynamic";
import SmoothScroll from "@/components/layout/SmoothScroll";
import LoadingScreen from "@/components/layout/LoadingScreen";
import Navigation from "@/components/layout/Navigation";
import Footer from "@/components/layout/Footer";
import Background from "@/components/effects/Background";
import CustomCursor from "@/components/effects/CustomCursor";
import Hero from "@/components/sections/Hero";
import About from "@/components/sections/About";
import Projects from "@/components/sections/Projects";
import AILab from "@/components/sections/AILab";
import Skills from "@/components/sections/Skills";
import Experience from "@/components/sections/Experience";
import Contact from "@/components/sections/Contact";

const HeroScene = dynamic(() => import("@/components/three/HeroScene"), {
  ssr: false,
  loading: () => null,
});

export default function Home() {
  const [isLoading, setIsLoading] = useState(true);
  const [isMobile, setIsMobile] = useState(false);

  useEffect(() => {
    setIsMobile(window.innerWidth < 768);
  }, []);

  const handleLoadingComplete = useCallback(() => {
    setIsLoading(false);
  }, []);

  return (
    <SmoothScroll>
      {isLoading && <LoadingScreen onComplete={handleLoadingComplete} />}
      <CustomCursor />
      <Background />
      <Navigation />

      <main>
        <section id="hero" className="relative min-h-screen">
          {!isMobile && <HeroScene />}
          <Hero isLoaded={!isLoading} />
        </section>

        <About />
        <Projects />
        <AILab />
        <Skills />
        <Experience />
        <Contact />
      </main>

      <Footer />
    </SmoothScroll>
  );
}
